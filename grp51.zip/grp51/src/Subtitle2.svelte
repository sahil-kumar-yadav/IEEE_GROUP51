<script>
  import Subtitle1 from "./Subtitle1.svelte";

  import Action_title from "./Action_title.svelte";

  import Actionbar from "./Actionbar.svelte";

  import header from "./Header.svelte";
</script>

<div class="subtitle">
  Timing Function
  <div class="timingFunction">
    <div class="dropdownWrapper">
      <div class="currentDropdownItem">
        <span class="dropdownItemName">linear </span>
        <span class="arrowDown">▼</span>
      </div>
    </div>
  </div>
</div>

<style>
  .subtitle {
    background-color: whitesmoke;
    font-family: "Poppins";
    color: black;
    font-weight: 900;
    font-size: 12px;
    line-height: 20px;
    margin-top: 15px;
  }

  .timingFunction {
    height: 30px;
  }

  .dropdownWrapper {
    width: 100%;
    height: 100%;
    position: relative;
    box-sizing: border-box;
    pointer-events: auto;
  }

  .currentDropdownItem {
    border: 2px solid #070708;
    border-radius: 4px;
    font-weight: 700;
    padding-left: 3px;
    font-family: "Poppins";
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    width: 100%;
    height: 100%;
    position: relative;
    box-sizing: border-box;
  }
</style>
