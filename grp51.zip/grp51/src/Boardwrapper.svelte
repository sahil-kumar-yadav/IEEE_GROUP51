<script>
  import Actionbody from "./Actionbody.svelte";

  import Subtitle5 from "./Subtitle4.svelte";

  import Subtitle4 from "./Subtitle5.svelte";

  import Board from "./Board.svelte";

  import Subtitle3 from "./Subtitle3.svelte";

  import Subtitle2 from "./Subtitle2.svelte";

  import Subtitle1 from "./Subtitle1.svelte";

  import Action_title from "./Action_title.svelte";

  import Actionbar from "./Actionbar.svelte";

  import header from "./Header.svelte";
</script>

<div class="Boardwrapper">
  <div style="width: 300px;">
    <div class="action">
      <div style="opacity">
        <div>
          <Actionbody />
          <Subtitle2 />
          <Subtitle3 />
          <Subtitle5 />
          <Subtitle4 />

          <div class="subtitle actionBtnWrap centered">
            <a href="actionButton">Animations</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <Board />
</div>

<style>
  .Boardwrapper{
    background-color: rgb(16, 210, 81);
  }
</style>
