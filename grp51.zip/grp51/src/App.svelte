<!-- npm run dev -->
<script>

  import Boardwrapper from './Boardwrapper.svelte';

  import Actionbar from './Actionbar.svelte';

  import Header from './Header.svelte';

</script>

<main>
  <Header></Header>  
  <div class="main">
    <Actionbar></Actionbar>
    <Boardwrapper></Boardwrapper>
  </div>
</main>

<style>
  
</style>
