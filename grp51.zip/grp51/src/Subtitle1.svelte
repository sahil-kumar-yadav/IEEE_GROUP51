<script>
  import Action_title from "./Action_title.svelte";

  import Actionbar from "./Actionbar.svelte";

  import header from "./Header.svelte";
</script>

<div class="subtitle">
  Duration
  <div class="durationInput">
    <div class="durationText">
      <input placeholder="0.6" class="outlinedInput" />
    </div>
    <div class="durationType">
      <div class="dropdownWrapper">
        <div class="currentDropdownItem">
          <span class="dropdownItemName">s </span>
          <span class="arrowDown">▼</span>
        </div>
      </div>
    </div>
  </div>
</div>

<style>
  .subtitle {
    font-family: "Poppins";
    color: black;
    font-weight: 900;
    font-size: 12px;
    line-height: 20px;
    margin-top: 15px;
    background-color: whitesmoke;
  }

  .durationInput {
    display: flex;
    align-items: center;
    height: 30px;
  }

  .durationText {
    height: 100%;
    width: 70%;
    margin-right: 5px;
  }

  .outlinedInput {
    outline: 0;
    border: 2px solid #0b0b0b;
    padding: 5px;
    border-radius: 4px;
    width: 100%;
    height: 100%;
    font-family: "Poppins";
    font-weight: 700;
    color: black;
    box-sizing: border-box;
  }

  .durationType {
    height: 100%;
    width: 20%;
    display: flex;
    align-items: center;
  }

  .dropdownWrapper {
    font-weight: 700;
    font-family: "Poppins";
    cursor: pointer;
    pointer-events: auto;
    width: 100%;
    height: 100%;
    position: relative;
    box-sizing: border-box;
  }

  .currentDropdownItem {
    border: 2px solid black;
    border-radius: 4px;
    font-weight: 700;
    padding-left: 3px;
    font-family: "Poppins";
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    
  }

  .dropdownItemName {
    font-size: 12px;
    display: flex;
    justify-content: center;
    align-items: center;
    padding-right: 4px;
  }

  .arrowDown {
    font-size: 12px;
    display: flex;
    justify-content: center;
    align-items: center;
    padding-right: 4px;
  }
</style>
