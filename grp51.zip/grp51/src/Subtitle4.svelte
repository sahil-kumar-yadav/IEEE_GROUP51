<script>
  import Board from "./Board.svelte";

  import Subtitle3 from "./Subtitle3.svelte";

  import Subtitle2 from "./Subtitle2.svelte";

  import Subtitle1 from "./Subtitle1.svelte";

  import Action_title from "./Action_title.svelte";

  import Actionbar from "./Actionbar.svelte";

  import header from "./Header.svelte";
</script>

<!-- <div class="subtitle">
  <div class="durationInput">
    <div class="durationText">
      <input class="outlinedInput" />
    </div>
    <div class="durationType">
      <input style="vertical-align: middle;" type="checkbox" />
    </div>
  </div>
</div> -->

<div class="subtitle">
  <span>Iteration</span>
  <!-- svelte-ignore a11y-label-has-associated-control -->
  <label class="infiniteCheckboxTitle">Infinite</label>
  <br />
  <div class="durationInput">
    <div class="durationText"><input class="outlinedInput" /></div>
    <div class="durationType">
      <input style="vertical-align: middle;" type="checkbox" />
    </div>
  </div>
</div>

<style>
  .subtitle {
    font-family: "Poppins";
    color: black;
    font-weight: 900;
    font-size: 12px;
    line-height: 20px;
    margin-top: 15px;
    background-color: whitesmoke;
  }

  .infiniteCheckboxTitle {
  position: absolute;
  right: 30px;
}

.durationInput {
  display: flex;
  align-items: center;
  height: 30px;
}

.durationText {
  height: 100%;
  width: 70%;
  margin-right: 5px;
}

.outlinedInput {
  outline: 0;
  border: 2px solid black;
  padding: 5px;
  border-radius: 4px;
  width: 100%;
  height: 100%;
  font-family: "Poppins";
  font-weight: 700;
  color: black;
  box-sizing: border-box;
}

.durationType {
  height: 100%;
  width: 20%;
  display: flex;
  align-items: center;
}
</style>
