<script>
  import Board from "./Board.svelte";

  import Subtitle4 from "./Subtitle4.svelte";

  import Subtitle3 from "./Subtitle3.svelte";

  import Subtitle2 from "./Subtitle2.svelte";

  import Subtitle1 from "./Subtitle1.svelte";

  import Action_title from "./Action_title.svelte";

  import Actionbar from "./Actionbar.svelte";

  import header from "./Header.svelte";
</script>

<div class="subtitle">
  Direction
  <div class="timingFunction">
    <div class="dropdownWrapper">
      <div class="currentDropdownItem">
        <span class="dropdownItemName">normal </span>
        <span class="arrowDown">▼</span>
      </div>
    </div>
  </div>
</div>

<style>
  .subtitle {
    font-family: "Poppins";
    color: black;
    font-weight: 900;
    font-size: 12px;
    line-height: 20px;
    margin-top: 15px;
    background-color: whitesmoke;
  }

  .timingFunction {
    height: 30px;
  }

  .dropdownWrapper {
    pointer-events: auto;
    width: 100%;
    height: 100%;
    position: relative;
    box-sizing: border-box;
  }

  .currentDropdownItem {
    border: 2px solid black;
    border-radius: 4px;
    font-weight: 700;
    padding-left: 3px;
    font-family: "Poppins";
    cursor: pointer;
    display: flex;
    justify-content: space-between;
  }

  .dropdownItemName {
    font-size: 12px;
    display: flex;
    justify-content: center;
    align-items: center;
    padding-right: 4px;
  }

  .arrowDown {
    font-size: 12px;
    display: flex;
    justify-content: center;
    align-items: center;
    padding-right: 4px;
  }

  


</style>
