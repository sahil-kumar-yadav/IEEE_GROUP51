<script>
  import Subtitle5 from "./Subtitle4.svelte";

  import Subtitle4 from "./Subtitle5.svelte";

  import Board from "./Board.svelte";

  import Subtitle3 from "./Subtitle3.svelte";

  import Subtitle2 from "./Subtitle2.svelte";

  import Subtitle1 from "./Subtitle1.svelte";

  import Action_title from "./Action_title.svelte";

  import Actionbar from "./Actionbar.svelte";

  import header from "./Header.svelte";
</script>

<div class="actionbody">
  <Action_title />
  <div class="subtitle">Object</div>
  <div class="object">
    <div class="object-bg-blue" />
    <img src="" alt="1" />
    <div class="object-bg-yellow" />
    <img src="" alt="2" />
    <div class="object-bg-green" />
    <img src="" alt="3" />
  </div>
  <Subtitle1 />
</div>

<style>
  .actionbody {
    background-color: wheat;
  }
  .object {
    display: flex;
    margin: 10px 5px;
  }
  .object-bg-blue {
    width: 40px;
    height: 40px;
    border-radius: 50px;
    margin-right: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    background-color: #552cf6;
  }

  .object-bg-yellow {
    width: 40px;
    height: 40px;
    border-radius: 50px;
    margin-right: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    background-color: #d0d313;
  }

  .object-bg-green {
    width: 40px;
    height: 40px;
    border-radius: 50px;
    margin-right: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    background-color: #41d0b6
  }
</style>
