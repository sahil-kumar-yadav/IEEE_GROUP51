<script>
  import Actionbar from "./Actionbar.svelte";

  import header from "./Header.svelte";
</script>

<div class="Actiontitle">
  Create <img src="" alt="exit">
  <!-- <a class="name">create</a> -->
</div>

<style>
  .Actiontitle {
    display: flex;
    margin-bottom: 40px;
    background-color: whitesmoke;
    justify-content: space-between;
    font-family: "Poppins";
    font-size: 18px;
    font-weight: bolder;
  }
</style>
