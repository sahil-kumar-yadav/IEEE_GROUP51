<script>
  import header from './Header.svelte';

</script>

<div class="actionbar">
      <div class="actionbartop" /> <img src="" alt="logo">
      <div class="actionbarbody" /> Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem sequi laudantium, tempore pariatur vero saepe, ratione corporis consectetur id est qui aliquam. Excepturi!
      <div class="actionbarfooter" />
    </div>

<style>
  .actionbar{
    background-color: red;
  }
</style>

