<script>
  import Actionbar from './Actionbar.svelte';

  import header from './Header.svelte';

</script>

<div class="action">
          <div style="opacity">
            <div>
              <div class="actionbody">
                <div class="actiontitle">
                  <!-- <a class="name">create</a> -->
                </div>
                <div class="subtitle">Object</div>
                <div class="object">
                  <div class="object-bg-blue" />
                  <div class="object-bg-yellow" />
                  <div class="object-bg-green" />
                </div>
                <div class="subtitle">
                  Duration
                  <div class="durationInput">
                    <div class="durationText">
                      <input placeholder="0.6" class="outlinedInput" />
                    </div>
                    <div class="durationType">
                      <div class="dropdownWrapper">
                        <div class="currentDropdownItem">
                          <span class="dropdownItemName">s </span>
                          <span class="arrowDown">▼</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="subtitle">
                  Timing Function
                  <div class="timingFunction">
                    <div class="dropdownWrapper">
                      <div class="currentDropdownItem">
                        <span class="dropdownItemName">linear </span>
                        <span class="arrowDown">▼</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="subtitle">
                  Delay
                  <div class="durationInput">
                    <div class="durationText">
                      <input class="outlinedInput" />
                    </div>
                    <div class="durationType">
                      <div class="dropdownWrapper">
                        <div class="currentDropdownItem">
                          <span class="dropdownItemName">s </span>
                          <span class="arrowDown">▼</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="subtitle">
                 
                  <div class="durationInput">
                    <div class="durationText">
                      <input class="outlinedInput" />
                    </div>
                    <div class="durationType">
                      <input style="vertical-align: middle;" type="checkbox" />
                    </div>
                  </div>
                </div>
                <div class="subtitle">
                  Direction
                  <div class="timingFunction">
                    <div class="dropdownWrapper">
                      <div class="currentDropdownItem">
                        <span class="dropdownItemName">normal </span>
                        <span class="arrowDown">▼</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="subtitle actionBtnWrap centered">
                  <a href="actionButton">Animations</a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="board">
          <div class="boardhead">
            <div class="zoombtns">
              <div class="zoom" />
            </div>
          </div>
        </div>

<style>
  .action{
    background-color: rgb(84, 30, 116);
  }
</style>

