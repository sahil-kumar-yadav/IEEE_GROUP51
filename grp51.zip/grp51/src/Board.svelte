<script>
  import Subtitle3 from "./Subtitle3.svelte";

  import Subtitle2 from "./Subtitle2.svelte";

  import Subtitle1 from "./Subtitle1.svelte";

  import Action_title from "./Action_title.svelte";

  import Actionbar from "./Actionbar.svelte";

  import header from "./Header.svelte";
</script>

<!-- <div class="board">
  <div class="boardhead">
    <div class="zoombtns">
      <div class="zoom" />
    </div>
  </div>
</div> -->

<div class="board">
  <div class="boardHead">
    <div class="zoomBtns">
      <div class=" zoom " />
      <div class=" zoom " />
    </div>
  </div>
  <div class="boardBody">
    <div class="animations" style="opacity: 1;">
      <div class="animations">
        <div
          class="carWrapper"
          style="transform: translateY(0px) translateZ(0px);"
        >
          <!-- <img
            class="car"
            src="/static/media/dragon.0a5a1b10.png"
            alt="dragon"
          /> -->
        </div>
        <div class="animationsWrapper" />
        <div class="animationsCloseIcon"></div>

        <div
          class="swiper-container swiper-container-initialized swiper-container-horizontal"
        >
          <div class="swiper-wrapper">
            <div
              class="animationItem animationCategory swiper-slide swiper-slide-active"
              style="margin-right: 10px;"
            >
              Rotations
            </div>
            <div
              class="animationItem animationCategory swiper-slide swiper-slide-next"
              style="margin-right: 10px;"
            >
              Rotations 2
            </div>
            <div
              class="animationItem animationCategory swiper-slide"
              style="margin-right: 10px;"
            >
              Flip
            </div>
            <div
              class="animationItem animationCategory swiper-slide"
              style="margin-right: 10px;"
            >
              Flip 2
            </div>
            <div
              class="animationItem animationCategory swiper-slide"
              style="margin-right: 10px;"
            >
              Slide
            </div>
            <div
              class="animationItem animationCategory swiper-slide"
              style="margin-right: 10px;"
            >
              Slide-2
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div
    style="transform: scale(1); opacity: 1;"
    id="objectSquare"
    class="objectSquare"
  />
</div>

<!-- </div> -->
<style>
  .board {
    width: 100%;
    height: 100%;
    max-height: 100%;
    /* background: linear-gradient(90deg,#f6f5fa 28px,transparent 1%) 50%,linear-gradient(#f6f5fa 28px,transparent 1%) 50%,#d2cde6; */
    background-color: blanchedalmond;
    background-size: auto, auto, auto;
    background-size: 30px 30px;
    display: flex;
    flex-direction: column;
    position: relative;
    z-index: 500;
  }
  .boardHead {
    display: flex;
    padding: 30px;
    justify-content: space-between;
  }
  .zoomBtns {
    display: flex;
  }

  .zoom {
    width: 40px;
    height: 40px;
    border-radius: 20px;
    background-color: #fff;
    margin-right: 5px;
    box-shadow: 0 3px 8px 0 #c7c7c7;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 22px;
    font-family: "Poppins";
    font-weight: 700;
    color: #9893aa;
    cursor: pointer;
  }

  .boardBody {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;
    width: 100%;
    position: relative;
  }

  .animations {
    position: relative !important;
    z-index: 1000 !important;
    top: -100px !important;
    display: flex;
    justify-content: center;
  }

  .carWrapper {
    position: absolute;
    z-index: 100;
    top: -40px;
  }

  .animationsWrapper {
    /* min-width: unset; */
    width: 80vw;
    background-color: #fff !important;
    height: 90px;
    min-width: 400px;
    max-width: 900px;
    border-radius: 10px;
    box-shadow: -2px 3px 12px -5px #e2e2e2;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    z-index: 1000;
  }

  .swiper-container {
    margin-left: auto;
    margin-right: auto;
    position: relative;
    overflow: hidden;
    list-style: none;
    padding: 0;
    z-index: 1;
  }

  .swiper-wrapper {
    position: relative;
    width: 100%;
    height: 100%;
    z-index: 1;
    display: flex;
    transition-property: transform;
    box-sizing: content-box;
  }

  .main .boardBody .animations .animationsWrapper .animationItem {
    font-size: 11px !important;
    padding: 0 10px !important;
  }

  /* .animationsWrapper .animationCategory {
    background-color: #d6d4de !important;
    color: #5f5e61 !important;
  }
  .animationsWrapper .animationItem {
    width: -webkit-fit-content;
    width: -moz-fit-content;
    width: fit-content;
    height: 40px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #d6d4de;
    font-family: "Poppins";
    color: #5f5e61;
    font-weight: 600;
    border-radius: 10px;
    cursor: pointer;
    font-size: 14px;
    padding: 0 20px;
    position: relative;
  } */
  .swiper-slide {
    flex-shrink: 0;
    width: 100%;
    height: 100%;
    position: relative;
    transition-property: transform;
  }

  .objectSquare {
    position: absolute;
    width: 200px;
    height: 200px;
    background-color: purple;
    border-radius: 10px;
    width: 100px !important;
    height: 100px !important;
    position: relative;
    z-index: 500;
  }
</style>
