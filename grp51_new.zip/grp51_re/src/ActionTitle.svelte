<script>
  import Actionbar from "./Actionbar.svelte";
</script>

<div class="actionTitle">
  <a href=" " class="name">Create</a>
</div>

<style>
  .actionTitle {
    font-family: "Poppins";
    display: flex;
    justify-content: space-between;
    margin-bottom: 40px;
  }
  .name {
    font-weight: 900;
    color: #070319;
    font-size: 20px;
    text-decoration: none;
  }
</style>
