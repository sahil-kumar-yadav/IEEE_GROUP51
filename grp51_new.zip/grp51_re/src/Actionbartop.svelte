<script>
</script>

<div class="actionBarTop">
  <div class="minLogo">
    <!-- <a>
                <img src="" class="logo" alt="logo">
                </a> -->
  </div>
</div>

<style>
  .actionBarTop {
    height: 10rem;
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .minLogo {
    background-color: rgb(219, 65, 65);
    border-radius: 5px;
    width: 50px;
    height: 50px;
    box-shadow: 0 3px 5px -1px #a8a8a8;
    overflow: hidden;
    cursor: pointer;
    display: flex;
    justify-content: center;
    align-items: center;
  }
</style>
