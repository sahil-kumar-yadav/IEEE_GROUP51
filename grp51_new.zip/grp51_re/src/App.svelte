<!-- npm run dev -->
<script>
  import Header from "./Header.svelte";

  import Main from "./Main.svelte";
</script>

<main>
  <body id="body"
    ><Header />
    <div id="root">
      <Main />
    </div>
  </body>
</main>

<style> 
 
</style>
