<script>
  import Main from "./Main.svelte";
</script>

<div class="preview__header" data-view="ctaHeader" data-item-id="29155663">
  <!-- <div class="preview__envato-logo">
    <a class="header-envato_market" href=" ">Envato Market</a>
  </div> -->

  <!-- <div id="js-preview__actions" class="preview__actions">
    <div class="preview__action--buy">
      <a class="header-buy-now e-btn--3d -color-primary" href=" ">Buy now</a>
    </div>
  </div> -->
  <h1>Devloperstar Animations</h1>
</div>

<style>
  .preview__header {
    font-size: 12px;
    height: 54px;
    background-color: black;
    color: white;
    z-index: 100;
    line-height: 54px;
    margin-bottom: 1px;
    text-align: center;
  }
  /* .preview__envato-logo {
    float: left;
    padding: 0 20px;
  }

  .preview__header {
    font-size: 12px;
    line-height: 54px;
  } */

  
</style>
