<script>
  import Board from './Board.svelte';

  import Action from "./Action.svelte";

  import Actionbar from "./Actionbar.svelte";
</script>

<div style="width: 300px;">
  <Action />
</div>
<Board></Board>

<style>
  
</style>
